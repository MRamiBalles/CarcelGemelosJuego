#define a b(
#define b(x) A x Z
a 42);
a 24);

#define __THROW __LEAF X
#define __LEAF __leaf__
x __THROW;
y __THROW;
