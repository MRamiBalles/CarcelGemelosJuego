_Static_assert (0 < -_Alignof (int), "_Alignof is signed");

int main() {}
