// variable_star.c
int T, b;
void f(void) {
  T * b;
}
