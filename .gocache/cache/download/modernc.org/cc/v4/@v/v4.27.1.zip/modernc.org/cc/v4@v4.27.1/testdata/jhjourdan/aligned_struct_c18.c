struct {
  _Alignas(int) char x;
};
