// typedef_star.c
typedef int T;
void f(void) {
  T * b;
}
