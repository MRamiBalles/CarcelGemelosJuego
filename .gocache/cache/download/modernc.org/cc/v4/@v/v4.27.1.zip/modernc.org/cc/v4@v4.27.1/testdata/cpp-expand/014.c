#define x _Pragma("STDC FP_CONTRACT ON") _Pragma("STDC FENV_ACCESS OFF")
x
