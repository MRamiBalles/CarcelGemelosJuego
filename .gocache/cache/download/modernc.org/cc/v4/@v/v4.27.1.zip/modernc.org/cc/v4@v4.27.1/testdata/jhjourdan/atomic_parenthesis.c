// atomic_parenthesis.c
int _Atomic (x);
