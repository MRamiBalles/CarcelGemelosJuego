# gc

Package GC is a Go compiler front end. (Work in progress, API unstable)

Installation

    $ go get modernc.org/gc/v2

Documentation: [pkg.go.dev/modernc.org/gc](https://pkg.go.dev/modernc.org/gc)
