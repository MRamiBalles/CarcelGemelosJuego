_Alignas(4) char c1;
unsigned _Alignas(long) char c2;
char _Alignas(16) c3;
char _Alignas(_Alignof(int)) c5;
