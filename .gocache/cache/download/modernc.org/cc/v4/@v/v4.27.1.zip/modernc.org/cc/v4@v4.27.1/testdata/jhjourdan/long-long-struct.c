typedef struct {
  long long foo;
} mystruct;
