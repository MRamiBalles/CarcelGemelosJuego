typedef int T;void f(int T){int T;}
