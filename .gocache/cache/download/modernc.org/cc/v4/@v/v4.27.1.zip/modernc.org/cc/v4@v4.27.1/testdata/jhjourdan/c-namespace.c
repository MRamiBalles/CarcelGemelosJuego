void bla1() {
  struct XXX;
  int XXX;
}

