int f(int x) {
	return x == 14 ? '"' : '\'';
}
