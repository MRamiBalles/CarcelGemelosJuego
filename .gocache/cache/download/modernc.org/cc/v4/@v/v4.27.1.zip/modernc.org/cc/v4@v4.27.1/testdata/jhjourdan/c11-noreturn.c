_Noreturn int f();
int _Noreturn f();
