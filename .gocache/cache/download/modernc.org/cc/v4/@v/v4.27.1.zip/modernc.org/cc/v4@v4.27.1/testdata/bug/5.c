#define zero 0

int main() {
	return zero;
}
