#define a b
a
#define a2  b2
a2
#define a3 b3//
a3
#define a4 b4 //
a4
#define a5 b5 c5
a5
#define a6 b6  c6
a6
#define a7 b7/**/c7
a7
#define a8 b8 /**/c8
a8
#define a9 b9/**/ c9
a9
#define a10 b10 /**/ c10
a10
