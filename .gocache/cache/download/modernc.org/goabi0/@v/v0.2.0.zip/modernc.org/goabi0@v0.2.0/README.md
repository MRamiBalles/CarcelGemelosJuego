[![Go Reference](https://pkg.go.dev/badge/modernc.org/goabi0.svg)](https://pkg.go.dev/modernc.org/goabi0)
[![LiberaPay](https://liberapay.com/assets/widgets/donate.svg)](https://liberapay.com/jnml/donate)
[![receives](https://img.shields.io/liberapay/receives/jnml.svg?logo=liberapay)](https://liberapay.com/jnml/donate)
[![patrons](https://img.shields.io/liberapay/patrons/jnml.svg?logo=liberapay)](https://liberapay.com/jnml/donate)

![logo_png](logo.png)

# goabi0

Package goabi0 provides helpers for generating Go assembler [ABI0] code.

[ABI0]:  https://go.dev/doc/asm
