#define SET_CMP_FUNC(name) c->name[0] = name ## 16_c;
SET_CMP_FUNC(A)
