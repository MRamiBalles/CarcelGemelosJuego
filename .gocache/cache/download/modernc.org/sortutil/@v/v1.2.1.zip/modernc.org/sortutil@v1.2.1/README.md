Packages in this repository:

Install: $ go get modernc.org/sortutil

Godocs:  [http://godoc.org/modernc.org/sortutil](http://godoc.org/modernc.org/sortutil)