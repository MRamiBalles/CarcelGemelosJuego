_Pragma("foo1") int i;

int j;

_Pragma("foo2") int a; _Pragma("foo3")
_Pragma("foo4") int b; _Pragma("foo5") int c;
