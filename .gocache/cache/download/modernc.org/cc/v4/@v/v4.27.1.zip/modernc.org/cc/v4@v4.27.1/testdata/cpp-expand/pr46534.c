#define S1 X
#define S2 S1 S1
S2
