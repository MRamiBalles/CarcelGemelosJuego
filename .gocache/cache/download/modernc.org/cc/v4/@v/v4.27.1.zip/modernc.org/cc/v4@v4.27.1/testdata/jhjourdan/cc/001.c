typedef int T;T f(T T){return 0;}T g(T)T T;{return 0;}
