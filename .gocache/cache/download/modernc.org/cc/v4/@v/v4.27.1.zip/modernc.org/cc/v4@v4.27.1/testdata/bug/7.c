#define FOO 42

int main() {
	int i = FOO;
}
