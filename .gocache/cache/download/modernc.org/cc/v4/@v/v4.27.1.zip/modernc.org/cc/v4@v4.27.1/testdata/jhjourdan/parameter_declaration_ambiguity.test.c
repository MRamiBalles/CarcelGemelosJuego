typedef int T;

void f(int(T), T x);
