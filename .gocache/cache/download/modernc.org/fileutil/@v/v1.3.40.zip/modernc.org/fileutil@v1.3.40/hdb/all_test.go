// Copyright (c) 2011 CZ.NIC z.s.p.o. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// blame: jnml, labs.nic.cz

package hdb // import "modernc.org/fileutil/hdb"

import (
	"testing"
)

func TestPlaceholder(t *testing.T) {
	t.Log("TODO") //TODO
}
